# Trabalho2IA


Os algoritmos estão divididos em pastas, cada pasta equivale a uma estratégia. 
Em cada pasta, tem um notebook correspondente para cada modelo e o seu ficheiro python correspondente. 
Para executar os programas basta escrever este comando: python3 (nome_do_ficheiro).py
